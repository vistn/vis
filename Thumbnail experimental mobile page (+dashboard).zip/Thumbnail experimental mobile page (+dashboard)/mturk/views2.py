from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from mturk.forms import InfoForm, ChooseForm
from mturk.models import ChooseArticle
from django.views.decorators.csrf import csrf_exempt
import uuid
import json, os, csv
import pandas as pd
import numpy as np
from django.views.decorators.csrf import csrf_exempt
from datetime import timedelta
import scipy.stats
from django.db.models.functions import Length
from django.core.files.storage import FileSystemStorage
from pandas import DataFrame as dataframe
import researchpy as rp


total = 0
complete = 0
min = 0
sec = 0
f = pd.DataFrame()

questions = {"q1":"1. This description effectively summarizes the context of the article.",
        "q2":"2. This thumbnail and the description are matching well.",
        "q3":"3. This thumbnail and the description effectively represent the article. "}

@csrf_exempt
def main(request):
    global attention, total, complete, f, min, sec
    total = ChooseArticle.objects.filter().count()
    complete = ChooseArticle.objects.filter(isFinish=True).count()
    f = pd.DataFrame(list(ChooseArticle.objects.filter(isFinish=True).values()))
    df = f['time']
    min = int(df.mean() // 60)
    sec = int(df.mean() % 60)
    context = {}
    context["total"] = total
    context["complete"] = complete
    context["min"] = min
    context["sec"] = sec
    return render(request, 'dashboard/dashmaster.html',  context)

def total_result(request):
    global total, complete, f, min, sec
    total = ChooseArticle.objects.filter().count()
    complete = ChooseArticle.objects.filter(isFinish=True).count()
    f = pd.DataFrame(list(ChooseArticle.objects.filter(isFinish=True).values()))
    df = f['time']
    min = int(df.mean() // 60)
    sec = int(df.mean() % 60)
 #   tn_type = request.GET['tn_type']
    context = {}
    context["total"] = total
    context["complete"] = complete
    context["min"] = min
    context["sec"] = sec
    context["questions"] = {}
    context["ans"] = {}


    df = pd.DataFrame(list(ChooseArticle.objects.filter(isFinish=True).values()))

    if not df.empty :
        cnt_list = []
        num = len(df.loc[df['type'] == 'a'].index)
        cnt_list.append(num)
        num = len(df.loc[df['type'] == 'b'].index)
        cnt_list.append(num)
        num = len(df.loc[df['type'] == 'c'].index)
        cnt_list.append(num)
        num = len(df.loc[df['type'] == 'd'].index)
        cnt_list.append(num)
        context["ans"]["cnt"] = cnt_list

        #카이검정
        #cnt_real = [elem/complete for elem in cnt_list]
        #print(cnt_list)
        #print(cnt_real)
        cnt_expect = [complete/4, complete/4, complete/4, complete/4]
        chis = scipy.stats.chisquare(cnt_list, cnt_expect)
        context["ans"]["chi"] = []
        context["ans"]["chi"].append({"text": "statistic", "val": round(chis.statistic,4)})
        context["ans"]["chi"].append({"text": "pVal", "val": round(chis.pvalue,4)})
        context["ans"]["chi"].append({"text": "total", "val": complete})
        #print("complete:", complete)
        #print(context["ans"]["chi"])

        # article 1
        cnt_list1 = []
        num1 = len(df.loc[df['tn'] == '1a'].index)
        cnt_list1.append(num1)
        anova_df1 = pd.DataFrame({'1a': np.ones(num), '1b': np.zeros(num), '1c': np.zeros(num), '1d': np.zeros(num)})
        num1 = len(df.loc[df['tn'] == '1b'].index)
        cnt_list1.append(num1)
        anova_df2 = pd.DataFrame({'1a': np.zeros(num), '1b': np.ones(num), '1c': np.zeros(num), '1d': np.zeros(num)})
        num1 = len(df.loc[df['tn'] == '1c'].index)
        cnt_list1.append(num1)
        anova_df3 = pd.DataFrame({'1a': np.zeros(num), '1b': np.zeros(num), '1c': np.ones(num), '1d': np.zeros(num)})
        num1 = len(df.loc[df['tn'] == '1d'].index)
        cnt_list1.append(num1)
        anova_df4 = pd.DataFrame({'1a': np.zeros(num), '1b': np.zeros(num), '1c': np.ones(num), '1d': np.zeros(num)})
        context["ans"]["cnt1"] = cnt_list1

        #카이검정
        #cnt_real = [elem/complete for elem in cnt_list]
        #print(cnt_list)
        #print(cnt_real)
        complete1 = ChooseArticle.objects.filter(isFinish=True, article=1).count()
        cnt_expect1 = [complete1/4, complete1/4, complete1/4, complete1/4]
        chis1 = scipy.stats.chisquare(cnt_list1, cnt_expect1)
        context["ans"]["chi1"] = []
        context["ans"]["chi1"].append({"text": "statistic", "val": round(chis1.statistic,4)})
        context["ans"]["chi1"].append({"text": "pVal", "val": round(chis1.pvalue,4)})
        context["ans"]["chi1"].append({"text": "total", "val": complete1})
        #print("complete article 1:", complete1)
        #print("article 1 statistic:", context["ans"]["chi1"])

        # article 2
        cnt_list2 = []
        num2 = len(df.loc[df['tn'] == '2a'].index)
        cnt_list2.append(num2)
        num2 = len(df.loc[df['tn'] == '2b'].index)
        cnt_list2.append(num2)
        num2 = len(df.loc[df['tn'] == '2c'].index)
        cnt_list2.append(num2)
        num2 = len(df.loc[df['tn'] == '2d'].index)
        cnt_list2.append(num2)
        context["ans"]["cnt2"] = cnt_list2

        #카이검정
        complete2 = ChooseArticle.objects.filter(isFinish=True, article=2).count()
        cnt_expect2 = [complete2/4, complete2/4, complete2/4, complete2/4]
        chis2 = scipy.stats.chisquare(cnt_list2, cnt_expect2)
        context["ans"]["chi2"] = []
        context["ans"]["chi2"].append({"text": "statistic", "val": round(chis2.statistic,4)})
        context["ans"]["chi2"].append({"text": "pVal", "val": round(chis2.pvalue,4)})
        context["ans"]["chi2"].append({"text": "total", "val": complete2})
        #print("complete article 2:", complete2)
        #print("article 2 statistic:", context["ans"]["chi2"])

        # article 3
        cnt_list3 = []
        num3 = len(df.loc[df['tn'] == '3a'].index)
        cnt_list3.append(num3)
        num3 = len(df.loc[df['tn'] == '3b'].index)
        cnt_list3.append(num3)
        num3 = len(df.loc[df['tn'] == '3c'].index)
        cnt_list3.append(num3)
        num3 = len(df.loc[df['tn'] == '3d'].index)
        cnt_list3.append(num3)
        context["ans"]["cnt3"] = cnt_list3

        #카이검정
        complete3 = ChooseArticle.objects.filter(isFinish=True, article=3).count()
        cnt_expect3 = [complete3/4, complete3/4, complete3/4, complete3/4]
        chis3 = scipy.stats.chisquare(cnt_list3, cnt_expect3)
        context["ans"]["chi3"] = []
        context["ans"]["chi3"].append({"text": "statistic", "val": round(chis3.statistic,4)})
        context["ans"]["chi3"].append({"text": "pVal", "val": round(chis3.pvalue,4)})
        context["ans"]["chi3"].append({"text": "total", "val": complete3})
        #print("complete article 3:", complete3)
        #print("article 3 statistic:", context["ans"]["chi3"])

        # article 4
        cnt_list4 = []
        num4 = len(df.loc[df['tn'] == '4a'].index)
        cnt_list4.append(num4)
        num4 = len(df.loc[df['tn'] == '4b'].index)
        cnt_list4.append(num4)
        num4 = len(df.loc[df['tn'] == '4c'].index)
        cnt_list4.append(num4)
        num4 = len(df.loc[df['tn'] == '4d'].index)
        cnt_list4.append(num4)
        context["ans"]["cnt4"] = cnt_list4

        #카이검정
        complete4 = ChooseArticle.objects.filter(isFinish=True, article=4).count()
        cnt_expect4 = [complete4/4, complete4/4, complete4/4, complete4/4]
        chis4 = scipy.stats.chisquare(cnt_list4, cnt_expect4)
        context["ans"]["chi4"] = []
        context["ans"]["chi4"].append({"text": "statistic", "val": round(chis4.statistic,4)})
        context["ans"]["chi4"].append({"text": "pVal", "val": round(chis4.pvalue,4)})
        context["ans"]["chi4"].append({"text": "total", "val": complete4})
        #print("complete article 4:", complete4)
        #print("article 4 statistic:", context["ans"]["chi4"])

    else:
        context["message"] = "No participants"

    return render(request, 'dashboard/totalResult.html', context)


def sec_to_min(x):
    m = x//60
    s = x%60
    if s<30:
        return int(m)
    else:
        return int(m+1)

@csrf_exempt
def stat_result(request):
    global total, complete, f, min, sec
    tn_type = request.GET['tn_type']
    complete = ChooseArticle.objects.filter(isFinish=True).count()
    context = {}
    context["total"] = total
    context["complete"] = complete
    context["min"] = min
    context["sec"] = sec
    context["questions"] = {}
    context["ans"] = {}

    df = pd.DataFrame(list(ChooseArticle.objects.filter(isFinish=True).values()))

    if tn_type=="a":
        question_list =[ {"number":"q0","question":"id"},
                         {"number":"q1","question":"thumbnail"},
                         {"number":"q2", "question":"Why would you choose (A)?"},
                         ]
    elif tn_type=="b":
        question_list =[ {"number":"q0","question":"id"},
                         {"number": "q1", "question": "thumbnail"},
                         {"number":"q2", "question":"Why would you choose (B)?"},
                         ]
    elif tn_type == "c":
            question_list = [{"number":"q0","question":"id"},
                             {"number": "q1", "question": "thumbnail"},
                             {"number": "q2", "question": "Why would you choose (C)?"},
                             ]
    elif tn_type == "d":
        question_list = [{"number":"q0","question":"id"},
                         {"number": "q1", "question": "thumbnail"},
                         {"number": "q2", "question": "Why would you choose (D)?"},
                         ]

    context['questions'] = question_list

    if not df.empty :
        tot = 0
        type_list = []
        if tn_type == "a":
            tot = ChooseArticle.objects.filter(isFinish=True, type='a').count()
            num = len(df.loc[df['tn'] == '1a'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '2a'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '3a'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '4a'].index)
            type_list.append(num)
            context["ans"]["type"] = "Thumbnail A"
            context["ans"]["cnttypes"] = type_list
            context["ans"]["typecol"] = ['1a', '2a', '3a', '4a']
        elif tn_type == 'b':
            tot =  ChooseArticle.objects.filter(isFinish=True, type='b').count()
            num = len(df.loc[df['tn'] == '1b'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '2b'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '3b'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '4b'].index)
            type_list.append(num)
            context["ans"]["type"] = "Thumbnail B"
            context["ans"]["cnttypes"] = type_list
            context["ans"]["typecol"] = ['1b', '2b', '3b', '4b']
        elif tn_type == 'c':
            tot =  ChooseArticle.objects.filter(isFinish=True, type='c').count()
            num = len(df.loc[df['tn'] == '1c'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '2c'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '3c'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '4c'].index)
            type_list.append(num)
            context["ans"]["type"] = "Thumbnail C"
            context["ans"]["cnttypes"] = type_list
            context["ans"]["typecol"] = ['1c', '2c', '3c', '4c']
        elif tn_type == 'd':
            tot = ChooseArticle.objects.filter(isFinish=True, type='d').count()
            num = len(df.loc[df['tn'] == '1d'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '2d'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '3d'].index)
            type_list.append(num)
            num = len(df.loc[df['tn'] == '4d'].index)
            type_list.append(num)
            context["ans"]["type"] = "Thumbnail D"
            context["ans"]["cnttypes"] = type_list
            context["ans"]["typecol"] = ['1d', '2d', '3d', '4d']
        #print(type_list)
        type_expect = [tot/4, tot/4, tot/4, tot/4]
        type_chis = scipy.stats.chisquare(type_list, type_expect)
        context["ans"]["chitypes"] = []
        context["ans"]["chitypes"].append({"text": "statistic", "val": round(type_chis.statistic, 4)})
        context["ans"]["chitypes"].append({"text": "pVal", "val": round(type_chis.pvalue, 4)})
        context["ans"]["chitypes"].append({"text": "total", "val": tot})

        cnt_list = []
        num = len(df.loc[df['type'] == 'a'].index)
        cnt_list.append(num)
        num = len(df.loc[df['type'] == 'b'].index)
        cnt_list.append(num)
        num = len(df.loc[df['type'] == 'c'].index)
        cnt_list.append(num)
        num = len(df.loc[df['type'] == 'd'].index)
        cnt_list.append(num)
        context["ans"]["cnt"] = cnt_list

        #카이검정
        #cnt_real = [elem/complete for elem in cnt_list]
        #print(cnt_list)
        #print(cnt_real)
        cnt_expect = [complete/4, complete/4, complete/4, complete/4]
        chis = scipy.stats.chisquare(cnt_list, cnt_expect)
        context["ans"]["chi"] = []
        context["ans"]["chi"].append({"text": "statistic", "val": round(chis.statistic,4)})
        context["ans"]["chi"].append({"text": "pVal", "val": round(chis.pvalue,4)})
        context["ans"]["chi"].append({"text": "total", "val": complete})
        #print("complete:", complete)
        #print(context["ans"]["chi"])

        if tn_type=='a':
            context["ans"]["title"] = "Thumbnail A"
            temp_df = df.loc[df['type'] == 'a']
            context["ans"]["des"] = temp_df[['id','tn','why_tn']].rename(columns = {'tn':'q1', 'why_tn':'q2',}).to_dict('records')
        elif tn_type=='b':
            context["ans"]["title"] = "Thumbnail B"
            temp_df = df.loc[df['type'] == 'b']
            context["ans"]["des"] = temp_df[['id','tn','why_tn']].rename(columns = {'tn':'q1', 'why_tn':'q2',}).to_dict('records')
        elif tn_type=='c':
            context["ans"]["title"] = "Thumbnail C"
            temp_df = df.loc[df['type'] == 'c']
            context["ans"]["des"] = temp_df[['id','tn','why_tn']].rename(columns = {'tn':'q1', 'why_tn':'q2',}).to_dict('records')
        elif tn_type=='d':
            context["ans"]["title"] = "Thumbnail D"
            temp_df = df.loc[df['type'] == 'd']
            context["ans"]["des"] = temp_df[['id','tn','why_tn']].rename(columns = {'tn':'q1', 'why_tn':'q2',}).to_dict('records')
    else:
        context["message"] = "No participants"

    return render(request, 'dashboard/compareResult.html', context)

@csrf_exempt
def question(request):
    global total, complete, f, min, sec
    context = {}
    context["total"] = total
    context["complete"] = complete
    context["min"] = min
    context["sec"] = sec

    df = pd.DataFrame(list(ChooseArticle.objects.filter(isFinish=True).values()))

    if not df.empty :
        context["ans"] = df[['id','q3']].to_dict('records')
        context['question'] = {"text":"What do you want to “see” from thumbnails?"}
    else:
        context["message"] = "No participants"

    return render(request, 'dashboard/question.html', context)


@csrf_exempt
def stat_participant(request):
    global total, complete, f, min, sec
    context = {}
    context["total"] = total
    context["complete"] = complete
    context["min"] = min
    context["sec"] = sec
    infolist = ['time','age', 'vis', 'gender', 'education', 'news']
    edu = ["High School","(University/College)","M.S", "PhD"]
    news = ["None","less than 2","less than 5","less than 7","more than 7"]
    context["user_info"] = []
   # f = pd.DataFrame(list(RankAnswer.objects.filter(isFinish=True, passTrap=True).values()))

    if complete>0:
        for info in infolist:
            df = f[info]
            df_list = list(df)
            vals = {}
            vals["text"] = info
            vals["child"] = []

            if info=="time":
                vals["stat"] = {}
                vals["stat"]["child"] = []
                vals["stat"]["child"].append({"text":"mean","child":[{"text":"min","val":int(df.mean()//60)},{"text":"sec","val":int(df.mean()%60)}] })
                vals["stat"]["child"].append({"text":"std","child":[{"text":"min","val":int(df.std()//60)},{"text":"sec", "val":int(df.std()%60)}] })
                vals["stat"]["child"].append({"text":"max","child":[{"text":"min","val":int(df.max()//60)},{"text":"sec","val":int(df.max()%60)}] })
                vals["stat"]["child"].append({"text":"min","child":[{"text":"min","val":int(df.min()//60)},{"text":"sec","val":int(df.min()%60)}] })
                new_time = list(map(lambda x: sec_to_min(x), df_list))
                category = sorted(set(new_time))
                vals["columns"] = category
                vals["child"] = []
                for c in category:
                   # vals["child"].append({"text": c, "val": new_time.count(c)})
                     vals["child"].append( new_time.count(c) )
            elif info=="age" or info=="attention" or info=="vis":
                vals["stat"] = {}
                vals["stat"]["child"] = []
                vals["stat"]["child"].append({"text":"mean","val":int(df.mean())})
                vals["stat"]["child"].append({"text":"std","val":int(df.std())})
                vals["stat"]["child"].append({"text":"max","val":int(df.max())})
                vals["stat"]["child"].append({"text":"min","val":int(df.min())})
                category = sorted(set(df))
                vals["columns"] = category
                vals["child"] = []
                for c in category:
                    #vals["child"].append({"text": c, "val": df_list.count(c)})
                    vals["child"].append( df_list.count(c) )
            else:
                if info=="education":
                    vals["columns"] = edu
                    vals["child"] = []
                    vals["stat"] = {}
                    vals["stat"]["child"] = []
                    vals["stat"]["child"].append({"text": "mean", "val": edu[int(df.mean())-1]})
                    vals["stat"]["child"].append({"text": "std", "val": int(df.std())})
                    vals["stat"]["child"].append({"text": "max", "val": edu[int(df.max())-1]})
                    vals["stat"]["child"].append({"text": "min", "val": edu[int(df.min())-1]})
                    for c in vals["columns"]:
                        #vals["child"].append({"text": c, "val": df_list.count(edu.index(c)+1)})
                        vals["child"].append(df_list.count(edu.index(c)+1))
                elif info=="news":
                    vals["columns"] = news
                    vals["child"] = []
                    vals["stat"] = {}
                    vals["stat"]["child"] = []
                    vals["stat"]["child"].append({"text": "mean", "val": news[int(df.mean())-1]})
                    vals["stat"]["child"].append({"text": "std", "val": int(df.std())})
                    vals["stat"]["child"].append({"text": "max", "val": news[int(df.max())-1]})
                    vals["stat"]["child"].append({"text": "min", "val": news[int(df.min())-1]})
                    for c in vals["columns"]:
                       # vals["child"].append({"text": c, "val": df_list.count(news.index(c)+1)})
                        vals["child"].append(df_list.count(news.index(c)+1))
                elif info=="gender":
                    category = sorted(set(df))
                    vals["columns"] = category
                    vals["child"] = []
                    for c in category:
                        # vals["child"].append({"text": c, "val": df_list.count(c)})
                        vals["child"].append(df_list.count(c))

            context['user_info'].append(vals)

        return render(request, 'dashboard/participant.html', context)
    else:
        context["message"] = "No participants"
        return render(request, 'dashboard/dashmaster.html', context)


@csrf_exempt
def stat_table(request):
    global total, complete, f, min, sec
    context = {}
    complete = ChooseArticle.objects.filter(isFinish=True).count()
    context["num"] = []

    df = pd.DataFrame(list(ChooseArticle.objects.filter(isFinish=True).values()))

    tn_1a = len(df.loc[df['tn'] == '1a'].index)
    tn_1b = len(df.loc[df['tn'] == '1b'].index)
    tn_1c = len(df.loc[df['tn'] == '1c'].index)
    tn_1d = len(df.loc[df['tn'] == '1d'].index)
    tn_2a = len(df.loc[df['tn'] == '2a'].index)
    tn_2b = len(df.loc[df['tn'] == '2b'].index)
    tn_2c = len(df.loc[df['tn'] == '2c'].index)
    tn_2d = len(df.loc[df['tn'] == '2d'].index)
    tn_3a = len(df.loc[df['tn'] == '3a'].index)
    tn_3b = len(df.loc[df['tn'] == '3b'].index)
    tn_3c = len(df.loc[df['tn'] == '3c'].index)
    tn_3d = len(df.loc[df['tn'] == '3d'].index)
    tn_4a = len(df.loc[df['tn'] == '4a'].index)
    tn_4b = len(df.loc[df['tn'] == '4b'].index)
    tn_4c = len(df.loc[df['tn'] == '4c'].index)
    tn_4d = len(df.loc[df['tn'] == '4d'].index)

    total_1a = len(df.loc[df['not1'] == '1a'].index) + len(df.loc[df['not2'] == '1a'].index) + len(
        df.loc[df['not3'] == '1a'].index) + tn_1a
    total_1b = len(df.loc[df['not1'] == '1b'].index) + len(df.loc[df['not2'] == '1b'].index) + len(
        df.loc[df['not3'] == '1b'].index) + tn_1b
    total_1c = len(df.loc[df['not1'] == '1c'].index) + len(df.loc[df['not2'] == '1c'].index) + len(
        df.loc[df['not3'] == '1c'].index) + tn_1c
    total_1d = len(df.loc[df['not1'] == '1d'].index) + len(df.loc[df['not2'] == '1d'].index) + len(
        df.loc[df['not3'] == '1d'].index) + tn_1d
    total_2a = len(df.loc[df['not1'] == '2a'].index) + len(df.loc[df['not2'] == '2a'].index) + len(
        df.loc[df['not3'] == '2a'].index) + tn_2a
    total_2b = len(df.loc[df['not1'] == '2b'].index) + len(df.loc[df['not2'] == '2b'].index) + len(
        df.loc[df['not3'] == '2b'].index) + tn_2b
    total_2c = len(df.loc[df['not1'] == '2c'].index) + len(df.loc[df['not2'] == '2c'].index) + len(
        df.loc[df['not3'] == '2c'].index) + tn_2c
    total_2d = len(df.loc[df['not1'] == '2d'].index) + len(df.loc[df['not2'] == '2d'].index) + len(
        df.loc[df['not3'] == '2d'].index) + tn_2d
    total_3a = len(df.loc[df['not1'] == '3a'].index) + len(df.loc[df['not2'] == '3a'].index) + len(
        df.loc[df['not3'] == '3a'].index) + tn_3a
    total_3b = len(df.loc[df['not1'] == '3b'].index) + len(df.loc[df['not2'] == '3b'].index) + len(
        df.loc[df['not3'] == '3b'].index) + tn_3b
    total_3c = len(df.loc[df['not1'] == '3c'].index) + len(df.loc[df['not2'] == '3c'].index) + len(
        df.loc[df['not3'] == '3c'].index) + tn_3c
    total_3d = len(df.loc[df['not1'] == '3d'].index) + len(df.loc[df['not2'] == '3d'].index) + len(
        df.loc[df['not3'] == '3d'].index) + tn_3d
    total_4a = len(df.loc[df['not1'] == '4a'].index) + len(df.loc[df['not2'] == '4a'].index) + len(
        df.loc[df['not3'] == '4a'].index) + tn_4a
    total_4b = len(df.loc[df['not1'] == '4b'].index) + len(df.loc[df['not2'] == '4b'].index) + len(
        df.loc[df['not3'] == '4b'].index) + tn_4b
    total_4c = len(df.loc[df['not1'] == '4c'].index) + len(df.loc[df['not2'] == '4c'].index) + len(
        df.loc[df['not3'] == '4c'].index) + tn_4c
    total_4d = len(df.loc[df['not1'] == '4d'].index) + len(df.loc[df['not2'] == '4d'].index) + len(
        df.loc[df['not3'] == '4d'].index) + tn_4d


    context["num"].append({"thumbnail": "1a", "cnt": tn_1a, "total_cnt": total_1a})
    context["num"].append({"thumbnail": "1b", "cnt": tn_1b, "total_cnt": total_1b})
    context["num"].append({"thumbnail": "1c", "cnt": tn_1c, "total_cnt": total_1c})
    context["num"].append({"thumbnail": "1d", "cnt": tn_1d, "total_cnt": total_1d})
    context["num"].append({"thumbnail": "2a", "cnt": tn_2a, "total_cnt": total_2a})
    context["num"].append({"thumbnail": "2b", "cnt": tn_2b, "total_cnt": total_2b})
    context["num"].append({"thumbnail": "2c", "cnt": tn_2c, "total_cnt": total_2c})
    context["num"].append({"thumbnail": "2d", "cnt": tn_2d, "total_cnt": total_2d})
    context["num"].append({"thumbnail": "3a", "cnt": tn_3a, "total_cnt": total_3a})
    context["num"].append({"thumbnail": "3b", "cnt": tn_3b, "total_cnt": total_3b})
    context["num"].append({"thumbnail": "3c", "cnt": tn_3c, "total_cnt": total_3c})
    context["num"].append({"thumbnail": "3d", "cnt": tn_3d, "total_cnt": total_3d})
    context["num"].append({"thumbnail": "4a", "cnt": tn_4a, "total_cnt": total_4a})
    context["num"].append({"thumbnail": "4b", "cnt": tn_4b, "total_cnt": total_4b})
    context["num"].append({"thumbnail": "4c", "cnt": tn_4c, "total_cnt": total_4c})
    context["num"].append({"thumbnail": "4d", "cnt": tn_4d, "total_cnt": total_4d})

    ov1 = (tn_1a + tn_1b + tn_1c + tn_1d)/complete
    ov2 = (tn_2a + tn_2b + tn_2c + tn_2d)/complete
    ov3 = (tn_3a + tn_3b + tn_3c + tn_3d)/complete
    ov4 = (tn_4a + tn_4b + tn_4c + tn_4d)/complete
    ovA = (tn_1a + tn_2a + tn_3a + tn_4a)
    ovB = (tn_1b + tn_2b + tn_3b + tn_4b)
    ovC = (tn_1c + tn_2c + tn_3c + tn_4c)
    ovD = (tn_1d + tn_2d + tn_3d + tn_4d)
    x2 = pow((tn_1a - ov1*ovA),2)/ov1*ovA + pow((tn_1b - ov1*ovB),2)/ov1*ovB + pow((tn_1c - ov1*ovC),2)/ov1*ovC + pow((tn_1d - ov1*ovD),2)/ov1*ovD+pow((tn_2a - ov2 * ovA), 2) / ov2 * ovA + pow((tn_2b - ov2 * ovB), 2) / ov2 * ovB + pow((tn_2c - ov2 * ovC),2) / ov2 * ovC + pow((tn_2d - ov2 * ovD), 2) / ov2 * ovD +pow((tn_3a - ov3 * ovA), 2) / ov3 * ovA + pow((tn_3b - ov3 * ovB), 2) / ov3 * ovB + pow((tn_3c - ov3 * ovC),2) / ov3 * ovC + pow((tn_3d - ov3 * ovD), 2) / ov3 * ovD +pow((tn_4a - ov4 * ovA), 2) / ov4 * ovA + pow((tn_4b - ov4 * ovB), 2) / ov4 * ovB + pow((tn_4c - ov4 * ovC),2) / ov4 * ovC + pow((tn_4d - ov4 * ovD), 2) / ov4 * ovD
    print(x2)

    print (context["num"])


    return render(request, 'dashboard/statTable.html', context)
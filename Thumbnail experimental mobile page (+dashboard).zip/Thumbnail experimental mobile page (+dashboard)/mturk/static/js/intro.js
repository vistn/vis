var result = bowser.getParser(window.navigator.userAgent);
var browser = result.parsedResult.browser.name +" ver."+ result.parsedResult.browser.version;
var platform = result.parsedResult.os.name +" "+ result.parsedResult.platform.type;
var s_height = window.screen.height;
var s_width = window.screen.width;
var windowSize = s_height + " x " + s_width;

//console.log(s_width + " " + s_height);
//if (s_width > s_height) {
//alert ("Please use Portrait!");
//}
//if (result.parsedResult.platform.type != 'mobile'){
//alert ("You are not using mobile. Please use a mobile device.")}

$('#show-irb').click(function(){window.open('/static/unistirb-19-33-a.pdf');});

$('#get-tutorial').click(function() {
var device = result.parsedResult.platform.type;
    if (device == 'mobile'){
    $("#introduction-1").css("display", "none");
    $("#start-experiment").css("display", "block");
    }
    else {alert ("You are not using mobile. Please use a mobile device. If you get the same notification when join mobile, please refresh the window.");}
});


$('#get-caution').click(function() {
    if ($('#agree1').prop('checked') == true){
    $("#start-experiment").css("display", "none");
    $("#caution").css("display", "block");
    }
    else {$("#agree1-feedback").css("display", "block");}
});


$("#browser").val(browser);
$("#platform").val(platform);
$("#windowSize").val(windowSize);

$('#write-info').click(function() {
var device = result.parsedResult.platform.type;
if (device == 'mobile') {
if ($('#agree2').prop('checked') == true){
window.location.href = 'http://vis.unist.ac.kr:33221/informationChoose';
}
else {$("#agree2-feedback").css("display", "block");}
}
else {
alert ("You are not using mobile. Please use a mobile device. If you get the same notification when join mobile, please refresh the window.");
window.location.href = 'http://vis.unist.ac.kr:33221/startChoose';
}
});


$('#get-tutorial2').click(function() {
    $("#tutorial2").css("display", "block");
});

$('#get-standard').click(function() {
    $("#standard").css("display", "block");
});
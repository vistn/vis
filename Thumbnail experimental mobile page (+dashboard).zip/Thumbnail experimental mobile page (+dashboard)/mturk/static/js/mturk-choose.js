var tn_chosen;
var address = "../../static/thumbnails/"
var index = cnt%2;
var shuffle;
var comb = '';
var not_1, not_2, not_3;
var combination= [
['1d', '2c', '3a', '4b'],
['1c', '2d', '3a', '4b'],
];

function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var temp = array[i];
      array[i] = array[j];
      array[j] = temp;
    }
    return array;
  }
var title1, title2, title3, title4;

// generate random four names;
var name1 = faker.name.firstName() + " " + faker.name.lastName();
var name2 = faker.name.firstName() + " " + faker.name.lastName();
var name3 = faker.name.firstName() + " " + faker.name.lastName();
var name4 = faker.name.firstName() + " " + faker.name.lastName();


 $("#btn-start-prediction").click(function(){
    $('#prediction_instruction').css("display", "none");
    //console.log(index);
    $("#index").val(index);
    shuffle = shuffleArray(combination[index]);
    for (var i=0; i<4; i++) {
    if (shuffle[i].substring(shuffle[i],1) == 1) {
        //var title1 = document.createElement("div");
        title1 = '<img class="btn-img" src="static\\thumbnails\\' + shuffle[i] + '.png" %}" style="width: 100%;  margin-bottom:50px;" /><h4>What Reddit Can Tell Us About NBA Fan Bases</h4><div align="left"><h5>By '+name1+'</h5></div>';}
    else if (shuffle[i].substring(shuffle[i],1) == 2) {
        //var title2 = document.createElement("div");
        title2 = '<img class="btn-img" src="static\\thumbnails\\' + shuffle[i] + '.png" %}" style="width: 100%;  margin-bottom:50px;" /><h4>How popular is Donald Trump?</h4><div align="left"><h5>By '+name2+'</h5></div>';}
    else if (shuffle[i].substring(shuffle[i],1) == 3) {
        //var title3 = document.createElement("div");
        title3 = '<img class="btn-img" src="static\\thumbnails\\' + shuffle[i] + '.png" %}" style="width: 100%;  margin-bottom:50px;" /><h4>Apple\'s Bad Month Is Getting Worse, Jeopardizing Its Status as Most Valuable Company</h4><div align="left"><h5>By '+name3+'</h5></div>';}
    else if (shuffle[i].substring(shuffle[i],1) == 4) {
        //var title4 = document.createElement("div");
        title4 = '<img class="btn-img" src="static\\thumbnails\\' + shuffle[i] + '.png" %}" style="width: 100%;  margin-bottom:50px;" /><h4>Brett Kavanaugh may have fared better with senators than voters</h4><div align="left"><h5>By '+name4+'</h5></div>';}
        };
    for (var i=1; i<5; i++) {
        var j = shuffle[i-1].substring(shuffle[i],1);
        var temp = 'title' + j.toString();
        $('#tn-btn' + i.toString()).html(eval(temp));
        comb = comb +  shuffle[i-1];
        };
    $('#show_thumbnail').css("display", "block");
    $("#comb").val(comb);
});

$('#tn-btn1').click(function() {
    var id = $(this).attr("id");
    saveThumbnails(id);
    });
$('#tn-btn2').click(function() {
    var id = $(this).attr("id");
    saveThumbnails(id);
    });
$('#tn-btn3').click(function() {
    var id = $(this).attr("id");
    saveThumbnails(id);
    });
$('#tn-btn4').click(function() {
    var id = $(this).attr("id");
    saveThumbnails(id);
    });

function saveThumbnails(id){
    var address = document.getElementById(id).firstChild.getAttribute('src');
    tn_chosen = address.substr(18, 2);
    // 선택받지 못한 썸네일 차례로 모델에 저장
    var last = comb.replace(tn_chosen, "");
    not_1 = last.substring(0,2);
    not_2 = last.substring(2,4);
    not_3 = last.substring(4,6);
    $("#not1").val(not_1);
    $("#not2").val(not_2);
    $("#not3").val(not_3);
 //   console.log( "not1 " + $("#not1").val());
    // 선택받은 썸네일 모델에 저장, 아티클 넘버, 썸네일 타입 따로 저장
    $("#tn").val(tn_chosen);
    $("#article").val(tn_chosen.substring(0, 1));
    $("#type").val(tn_chosen.substring(1, 2));
    // 다음 섹션 보여주기
    $("#show_thumbnail").css("display", "none");
    //이전 섹션 삭제
    $("#instruction-reason").css("display", "block");
};

//고른 or 안고른 썸네일 보여주는 양식
var first_add = "<img src='../../static/thumbnails/"
var second_add = "style='width:100%;margin-bottom:30px;'>"
var third_add = "style='width:100%;box-sizing: border-box;padding: 10px 0;'>"

$('#btn-start-reason').click(function() {
    $("#instruction-reason").css("display", "none");
    $("#get-reason").css("display", "block");
    // 고른 썸네일 보여주기 tn_chosen
    var show_tn = document.getElementById("chosen_tn");
    var anum = tn_chosen.substring(0, 1);
    var atitle = getTitle(anum);
    show_tn.innerHTML = '<h3 style="text-align:center;color:red;margin-bottom:10px;">Article you chose: '+tn_chosen+'</h3>'+first_add + tn_chosen +  ".png'" +second_add + atitle;
    var show_not1 = document.getElementById("tn_not1");
    var show_not2 = document.getElementById("tn_not2");
    var show_not3 = document.getElementById("tn_not3");
    var anum1 = not_1.substring(0, 1);
    var anum2 = not_2.substring(0, 1);
    var anum3 = not_3.substring(0, 1);
    var atitle1 = getTitle(anum1);
    var atitle2 = getTitle(anum2);
    var atitle3 = getTitle(anum3);
    tn_not1.innerHTML = '<h3 style="text-align:center;margin-bottom:10px;">'+not_1+'</h3>'+ first_add + not_1 +  ".png'" +second_add + atitle1;
    tn_not2.innerHTML = '<h3 style="text-align:center;margin-bottom:10px;">'+not_2+'</h3>'+ first_add + not_2 +  ".png'" +second_add + atitle2;
    tn_not3.innerHTML = '<h3 style="text-align:center;margin-bottom:10px;">'+not_3+'</h3>'+ first_add + not_3 +  ".png'" +second_add + atitle3;

    var thumb0 = document.getElementById("thumb0");
    var thumb1 = document.getElementById("thumb1");
    var thumb2 = document.getElementById("thumb2");
    var thumb3 = document.getElementById("thumb3");

    thumb0.innerHTML = '<p style="text-align:center;color:red;">'+tn_chosen+'</p>'+first_add + tn_chosen + ".png'" + third_add;
    thumb1.innerHTML = '<p style="text-align:center;">'+not_1+'</p>'+ first_add + not_1 + ".png'" + third_add;
    thumb2.innerHTML = '<p style="text-align:center;">'+not_2+'</p>'+ first_add + not_2 + ".png'" + third_add;
    thumb3.innerHTML = '<p style="text-align:center;">'+not_3+'</p>'+ first_add + not_3 + ".png'" + third_add;

    var galleryThumbs = new Swiper('.gallery-thumbs', {
      spaceBetween: 10,
      slidesPerView: 4,
      loop: false,
      freeMode: true,
      loopedSlides: 5, //looped slides should be the same
      watchSlidesVisibility: true,
      watchSlidesProgress: true,
    });
    var galleryTop = new Swiper('.gallery-top', {
      spaceBetween: 10,
      loop:false,
      loopedSlides: 5, //looped slides should be the same
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      thumbs: {
        swiper: galleryThumbs,
      },
    });

    });


function getTitle(anum){
    if (anum == 1) {
        return atitle = '<h4>What Reddit Can Tell Us About NBA Fan Bases</h4><div align="left"><h5>By '+name1+'</h5></div>';}
    else if (anum == 2) {
        return atitle = '<h4>How popular is Donald Trump?</h4><div align="left"><h5>By '+name2+'</h5></div>';}
    else if (anum == 3) {
        return atitle = '<h4>Apple\'s Bad Month Is Getting Worse, Jeopardizing Its Status as Most Valuable Company</h4><div align="left"><h5>By '+name3+'</h5></div>';}
    else if (anum == 4) {
        return atitle = '<h4>Brett Kavanaugh may have fared better with senators than voters</h4><div align="left"><h5>By '+name4+'</h5></div>';}
};

$('#submit-reason').click(function() {
$("#reason-feedback").css("display", "none");
    if($("#tn-reason").val().length>100){
        // 현재 블록 닫고 고른 이유 값 저장
        $("#get-reason").css("display", "none");
        $("#why_tn").val($('#tn-reason').val());
        // 함정문제 보여주기
        $("#check-trap").css("display", "block");
        // 함정문제용 기사 띄우기
         for (var i=1; i<5; i++) {
            var j = shuffle[i-1].substring(shuffle[i],1);
            var trap_temp = 'title' + j.toString();
            $('#trap' + i.toString()).html(eval(trap_temp));
        };
    }else
      {$("#reason-feedback").css("display", "block");} ;
});

$('#trap1').click(function() {
    var id = $(this).attr("id");
    Trap(id);
    $("#check-trap").css("display", "none");
    });
$('#trap2').click(function() {
    var id = $(this).attr("id");
    Trap(id);
    $("#check-trap").css("display", "none");
    });
$('#trap3').click(function() {
    var id = $(this).attr("id");
    Trap(id);
    $("#check-trap").css("display", "none");
    });
$('#trap4').click(function() {
    var id = $(this).attr("id");
    Trap(id);
    $("#check-trap").css("display", "none");
    });

function Trap (id){
    var address = document.getElementById(id).firstChild.getAttribute('src');
    var check = address.substr(18, 2);
    if (check != tn_chosen){
        $("#passTrap").val(false);
        $("#ans-form").submit();
    }
    else {
    $("#passTrap").val(true);
    $("#final-submit").css("display", "block");
    //$("#instruction-reasonnot").css("display", "block");
    }
    ;
}

$('#btn-start-notchosen').click(function() {
    $("#instruction-reasonnot").css("display", "none");
    var show_tn = document.getElementById("notchosen-1");
    var anum = not_1.substring(0, 1);
    var atitle = getTitle(anum);
    show_tn.innerHTML = first_add + not_1 +  ".png'" +second_add +atitle;
    $("#get-reason-not1").css("display", "block");

});

$('#submit-not1').click(function() {
    if($("#not1-reason").val().length>70){
        // 현재 블록 닫고 고른 이유 저장
        $("#get-reason-not1").css("display", "none");
        $("#why_not1").val($('#not1-reason').val());
        // 다음 not2 보여주기
        var show_tn = document.getElementById("notchosen-2");
        var anum = not_2.substring(0, 1);
        var atitle = getTitle(anum);
        show_tn.innerHTML = first_add + not_2 +  ".png'" +second_add +atitle;
        $("#get-reason-not2").css("display", "block");
    }else
        alert('Please write down more than 70 characters');
    });

$('#submit-not2').click(function() {
    if($("#not2-reason").val().length>70){
        // 현재 블록 닫고 고른 이유 저장
        $("#get-reason-not2").css("display", "none");
        $("#why_not2").val($('#not2-reason').val());
        // 다음 not3 보여주기
        var show_tn = document.getElementById("notchosen-3");
        var anum = not_3.substring(0, 1);
        var atitle = getTitle(anum);
        show_tn.innerHTML = first_add + not_3 +  ".png'" +second_add +atitle;
        $("#get-reason-not3").css("display", "block");
    }else
        alert('Please write down more than 70 characters');
    });

$('#submit-not3').click(function() {
    if($("#not3-reason").val().length>70){
        // 현재 블록 닫고 고른 이유 저장
        $("#get-reason-not3").css("display", "none");
        $("#why_not3").val($('#not3-reason').val());
        $("#final-submit").css("display", "block");
    }else
        alert('Please write down more than 70 characters');
    });

// 글자수 체크
$("#tn-reason").keyup(function(e) {
   var content = $(this).val();
   $('#counter').html("("+content.length+" / 280 characters)");
   $(this).val(content.substring(0, 280));
});

$("#not1-reason").keyup(function(e) {
   var content = $(this).val();
   $('#counter-not1').html("("+content.length+" / 280 characters)");
   $(this).val(content.substring(0, 280));
});

$("#not2-reason").keyup(function(e) {
   var content = $(this).val();
   $('#counter-not2').html("("+content.length+" / 280 characters)");
   $(this).val(content.substring(0, 280));
});

$("#not3-reason").keyup(function(e) {
   var content = $(this).val();
   $('#counter-not3').html("("+content.length+" / 280 characters)");
   $(this).val(content.substring(0, 280));
});


$('body').bind('copy paste',function(e) {
    e.preventDefault(); return false;
});

from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from mturk.forms import InfoForm, ChooseForm
from mturk.models import ChooseArticle
from django.views.decorators.csrf import csrf_exempt
import uuid

# Create your views here.

@csrf_exempt
def TurkMaster(request):
    return render(request, 'TurkMaster.html', {})

@csrf_exempt
def temp_info(request):
    return render(request, 'mturk/information.html', {})

@csrf_exempt
def temp_rank(request):
    return render(request, 'mturk/rank.html', {})

def finished(request):
    return render(request, 'mturk/finish.html', {})

cnt = 0
@csrf_exempt
def start_choose(request):
    if not request.session.session_key:
        request.session.create()
    session_id = request.session.session_key
    context = {}
    context['session_id'] = session_id
    form = InfoForm()
    return render(request, 'TurkMaster.html', {'form':form})

@csrf_exempt
def submit_choose_information(request):
    if request.method == 'POST':
        #save information
        form = InfoForm(request.POST)
        if form.is_valid():
            session_id = request.session.session_key
            num_results = ChooseArticle.objects.filter(session_id=session_id).count()

            if num_results > 0:
                return render(request, 'mturk/already.html')

            global cnt
            cnt = cnt + 1

            answer = ChooseArticle(session_id=session_id)
            answer.prolificID = form.cleaned_data["prolificID"]
            answer.age = form.cleaned_data["age"]
            answer.gender = form.cleaned_data["gender"]
            answer.education = form.cleaned_data["education"]
            answer.news = form.cleaned_data["news"]
            answer.vis = form.cleaned_data["vis"]
            answer.save()
            answer.platform = form.cleaned_data["platform"]
            answer.browser = form.cleaned_data["browser"]
            answer.windowSize = form.cleaned_data["windowSize"]
            answer.save()
            return render(request, 'mturk/choose.html', {'cnt':cnt})
        else:
            context = {}
            context["message"] = "Input is not valid"
            context["form"] = InfoForm()
            return render(request, 'mturk/information.html', context)
    else:
        context = {}
        context["message"] = "Input is not valid"
        context["form"] = InfoForm()
        return render(request, 'mturk/information.html', context)

@csrf_exempt
def submit_choose_answer(request):
    # POST 요청이면 폼 데이터를 처리한다
    if request.method == 'POST':
        # 폼 인스턴스를 생성하고 요청에 의한 데이타로 채운다 (binding):
        form = ChooseForm(request.POST)
        session_id = request.session.session_key
        randomString = str(uuid.uuid4()).replace("-", "")
        # 폼이 유효한지 체크한다:

        if form.is_valid():
            #answer = ChooseArticle.objects.last()
            answer = ChooseArticle.objects.get(session_id=session_id)
            #answer.token = randomString
            answer.tn = form.cleaned_data['tn']
            answer.type = form.cleaned_data['type']
            answer.article = form.cleaned_data['article']
            answer.comb = form.cleaned_data['comb']
            answer.why_tn = form.cleaned_data['why_tn']
            answer.not1 = form.cleaned_data['not1']
            answer.not2 = form.cleaned_data['not2']
            answer.not3 = form.cleaned_data['not3']
            #answer.why_not1 = form.cleaned_data['why_not1']
            #answer.why_not2 = form.cleaned_data['why_not2']
            #answer.why_not3 = form.cleaned_data['why_not3']
            answer.passTrap = form.cleaned_data['passTrap']
            answer.index = form.cleaned_data['index']
            if answer.passTrap:
                answer.isFinish = True
                answer.save()
                time = answer.finish - answer.start
                answer.time = int(time.total_seconds())
                answer.save()
                return render(request, 'mturk/finish.html')
            else:
                answer.isFinish = False
                answer.save()
                time = answer.finish - answer.start
                answer.time = int(time.total_seconds())
                answer.save()
                return render(request, 'mturk/fail.html')
    else:
        context = {'token': "Some Input is not exist"}
#       context['form'] = ChooseForm()
        return render(request, 'mturk/already.html', context)


def index(request):
    num_visits = request.session.get('num_visits', 0)
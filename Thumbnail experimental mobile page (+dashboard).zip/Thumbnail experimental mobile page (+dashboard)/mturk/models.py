from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

# Create your models here.
from django.conf import settings
from django.db import models
from django.utils import timezone

class ChooseArticle(models.Model):
    start = models.DateTimeField(auto_now_add=True)
    finish = models.DateTimeField(auto_now=True)
    time = models.IntegerField(default=0)
    # 높이, 너비
    width = models.IntegerField(default=0)
    height = models.IntegerField(default=0)
    # demographic fields --------------------
    age = models.IntegerField(default=0)
    gender = models.CharField(max_length=200,default="")
    education = models.IntegerField(default=0)
    vis = models.IntegerField(default=0)
    news = models.IntegerField(default=0)
    # 사용자 플랫폼, 브라우저, 디바이스 크기 체크
    platform = models.CharField(max_length=300, default="")
    browser = models.CharField(max_length=300, default="")
    windowSize = models.CharField(max_length=300, default="")
    # Finish 여부, 함정 통과 여부, session id, token, turkID 등등
    isFinish = models.BooleanField(default=False)
    passTrap = models.BooleanField(default=True)
    session_id = models.CharField(max_length=200,default="")
    #token = models.CharField(max_length=200,default="")
    prolificID = models.CharField(max_length=200,default="")
    # 고른 썸네일 이름, 타입, 기사
    tn = models.CharField(max_length=100, default="")
    type = models.CharField(max_length=100, default="")
    article = models.CharField(max_length=100, default="")
    # 안 고른 썸네일 3개의 조합
    comb = models.CharField(max_length=100, default="")
    # 고른 썸네일 이유
    why_tn = models.TextField(max_length=300, default="")
    # 안고른 썸네일 3개
    not1 = models.CharField(max_length=100, default="")
    not2 = models.CharField(max_length=100, default="")
    not3 = models.CharField(max_length=100, default="")
    index = models.CharField(max_length=100, default="")


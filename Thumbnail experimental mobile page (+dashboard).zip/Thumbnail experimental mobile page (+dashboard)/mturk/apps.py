from django.apps import AppConfig


class MturkConfig(AppConfig):
    name = 'mturk'

from django import forms
from .models import ChooseArticle

class InfoForm(forms.ModelForm):
    class Meta:
        model = ChooseArticle
        fields = ['prolificID', 'age', 'gender', 'education', 'news', 'vis', 'platform', 'browser', 'windowSize',]

class ChooseForm(forms.ModelForm):
    class Meta:
        model = ChooseArticle
        exclude = ['prolificID', 'age', 'gender', 'education', 'news', 'vis','platform', 'browser', 'windowSize',
                    'isFinish', 'session_id',
                    'start', 'finish', 'time', 'width', 'height', ]

from django.urls import path
from . import views
from . import views2

urlpatterns = [
    path('', views.TurkMaster, name='startChoose'),
    path('startChoose', views.start_choose, name='start'),
    path('informationChoose', views.submit_choose_information, name='info'),
    path('submitChoose', views.submit_choose_answer, name='submit'),
    path('finished', views.finished, name='finished'),
    path('dashboard', views2.total_result, name='total'),
    path('dashboard/main', views2.main, name='main'),
    path('dashboard/result', views2.stat_result, name='result'),
    path('dashboard/participant', views2.stat_participant, name='participant'),
    path('dashboard/table', views2.stat_table, name='table'),
]

